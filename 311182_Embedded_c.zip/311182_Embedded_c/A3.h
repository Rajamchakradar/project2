#ifndef A3_H_INCLUDED
#define A3_H_INCLUDED
// PWM 20%
#define PWM_20_PERCENT (205)

//PWM 40%
#define PWM_40_PERCENT (410)

//PWM 70%
#define PWM_70_PERCENT (717)

//PWM 95%
#define PWM_95_PERCENT (973)


#include <util/delay.h>
#include <avr/io.h>


void InitTimer();
void activity3_PWM(uint16_t temp);

#endif // A3_H_INCLUDED
