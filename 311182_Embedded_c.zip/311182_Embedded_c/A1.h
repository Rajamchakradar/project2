#ifndef __A1_H_
#define __A1_H_

#define F_CPU 16000000UL

/** LED Port Number */
#define LED_PORT (PORTD)

/**< LED Pin Number */
#define LED_PIN  (PORTD2)

/* Button*/
#define BUTTON_SENSOR  (PORTD0)

/*Temperature sensor*/
#define TEMP_SENSOR  (PORTD1)

#include <util/delay.h>
#include <avr/io.h>

void peripheral_init(void);

void TurnLED_ON();

void TurnLED_OFF();

int activity1_LED(void);


#endif
